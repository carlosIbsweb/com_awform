DROP TABLE IF EXISTS `#__awforms_registros`;
